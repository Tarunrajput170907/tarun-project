<?php
include 'connection.php';?>
<!DOCTYPE html>
<html lang="en">
<head>
    <style>
        div{
        border: 1px solid black;
        margin-top: auto;
        margin-bottom: auto;
        margin-right: auto;
        text-align: center;
        margin-left: auto;
        background-color: lightblue;
        }
        .center {
        text-align: center;
        }
        .button{
            background-color: skyblue; 
            border: none;
            color: white;
            padding: auto;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: auto;
        }
        .save{
            background-color:lightgreen; 
            border: none;
            color: white;
            padding: auto;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: auto;
        }
        #mydiv{          
            width: 200px;
            padding-left:5px;
            padding-top: 20px;
            text-align :center;
            height: 150px;
            background: lightblue;
            animation: mymove 5s infinite;
}
@keyframes mymove {
  50% {background-color: blue;}
}
    </style>
</head>
<body>
    <div id="mydiv" >
        <form action="" method="POST">
            <input  type="text" name="firstname" placeholder="FIRSTNAME"><br><br>
            <input type="text" name="lastname" placeholder="LASTNAME"><br><br>
            <input type="number" name="age" placeholder="AGE"><br><br>
            <input class="save" type="submit" name="save_btn" value="SAVE">
            <button class="button"><a href="view.php">VIEW</a></button>
        </form>
    </div>
<?php
if(isset($_POST['save_btn'])){
    $fname=$_POST['firstname'];
    $lname=$_POST['lastname'];
    $age=$_POST['age'];

    $query="INSERT INTO student(firstname,lastname,age) VALUES('$fname','$lname','$age')";
    $data=mysqli_query($con,$query);
    $data=mysqli_query($con,$query);
    if($data){
        ?>
        <script type="text/javascript">
            alert("data saved");
        </script>
        <?php
    }
    else{
        echo"please try again";
    }
    
}
?>
</body>
</html>