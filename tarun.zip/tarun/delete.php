<?php include 'connection.php';
$id=$_GET['id'];
$query="DELETE FROM student WHERE id='$id'";
$data=mysqli_query($con,$query);
if($data){
    ?>
    <script type="text/javascript">
        alert("data deleted sucessfully");
        window.open("http://localhost/tarun/veiw.php","_self");
    </script>
    <?php
} 
else{
    ?>
    <script type="text/javascript">
        alert("please try again");
    <?php
}



?>