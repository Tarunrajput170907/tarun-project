<style>
table, th, td {
  border: 1px solid black;
}

#myTABLE {
  border-spacing: 2px;
  animation: mymove 5s infinite;
}

@keyframes mymove {
  50% {border-spacing: 20px;}
}
</style>
<?php include 'connection.php';?>
<a href="index.php">home</a>
<table id="myTABLE" border="1px" cellpadding="10px" ceilspacing="0px">
    <tr>
        <th>firstname</th>
        <th>lastname</th>
        <th>age</th>
        <th colspan="2">actions</th>
    </tr>
    <?php
    $query="SELECT * FROM student";
    $data=mysqli_query($con,$query);
    $result=mysqli_num_rows($data);
    if($result){
        while($rows=mysqli_fetch_array($data)) {
            ?>
            <tr>
                <td><?php echo $rows['firstname']; ?></td>
                <td><?php echo $rows['lastname']; ?></td>
                <td><?php echo $rows['age']; ?></td>
                <td> <a href="update.php?id=<?php echo $rows['id']; ?>"> edit</a> </td>
                <td><a onclick="return confrim('are you sure, you want to delete?')" href="delete.php?id=<?php echo $rows['id']; ?>">Delete</a></td>
            </tr>
            <?php
        }
    }
    else{
        ?>
        <tr>
            <td> no record found</td>
        </tr>
        <?php
    }
    ?>
</table>